#Nama/Nim : Ari Pardomuan Manurung/16519044
#Tanggal  : Rabu, 22 April 2020
#Topik praktikum : Topik 3
#Deskripsi : Program membaca nama sebuah file teks, misalnya "saham.txt" dan
#            menuliskan nilai rata-rata kepemilikan saham dalam keadaan terurut berdasarkan
#            IdPemilik. Penulisan rata-rata dibulatkan dengan 2 angka di belakang koma
#            (gunakan fungsi formatting teks seperti pernah dilakukan pada praktikum sebelumnya).
#            Jika file teks kosong,tuliskan ke layar "File kosong". Akhir file ditandai dengan nilai 99999999.

#Program RataSaham
import tulisdata

# KAMUS
# namafile: string


# ALGORITMA PROGRAM UTAMA
namafile = input()
tulisdata.TulisDataSaham(namafile)


fileObject = open(namafile)
arraySaham = fileObject.readlines()
arraySahamLength = 0
for row in arraySaham:
  arraySahamLength += 1
A = [(99999999,"a",1) for i in range( (arraySahamLength//3) ) ]
j = 0

#Proses file to Array of tuples
for i in range(0, arraySahamLength, 3):
        if (i+2 < arraySahamLength ):
            A[j] = (int(arraySaham[i] ), str.rstrip(arraySaham[i+1] ), int(arraySaham[i+2] ) )
        j += 1
sahamku = arraySahamLength//3
#Insertion sort 
for i in range(sahamku):
  extract = A[i]
  for j in range(i-1, -1, -1):
    if A[j][0] > extract[0]:
      A[j+1] = A[j]
      A[j] = extract
    else:
      A[j+1] = extract
      break
#Konsolidasi dan perhitungan rata-rata sekaligus mengeprint output
i = 0
while(i<sahamku):
  noInduk = A[i][0]
  sumTotal = 0
  cnt = 0
  while (noInduk == A[i][0] ):
    sumTotal += A[i][2]
    cnt += 1
    i += 1
    if (i == sahamku ): break
  ans = float(sumTotal/cnt)
  print(str(noInduk) + "=", end='')
  print("%.2f" % ans)

#Jika kosong
if (sahamku == 0): print("File kosong")
